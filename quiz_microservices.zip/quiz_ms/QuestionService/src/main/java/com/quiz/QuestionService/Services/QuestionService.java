package com.quiz.QuestionService.Services;

import com.quiz.QuestionService.Model.Question;
import com.quiz.QuestionService.Repository.QuestionRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class QuestionService
{
    @Autowired
    QuestionRepo questionrepo;

    public List<Question> getQuestions() {
        return questionrepo.findAll();
    }

    public Optional<Question> getQuestionById(Integer id) {
        return questionrepo.findById(id);
    }

    public void create(Question question) {
        questionrepo.save(question);
    }

    public List<Question> getQuestionsByQuizId(Integer quizId) {
        return questionrepo.findByQuizId(quizId);
    }
}
