package com.quiz.QuestionService.Controllers;

import com.quiz.QuestionService.Model.Question;
import com.quiz.QuestionService.Services.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("question")
public class QuestionController
{
    @Autowired
    QuestionService questionservice;

    @GetMapping("/get")
    public List<Question> getQuestions()
    {
        return questionservice.getQuestions();
    }
    @GetMapping("/get/{id}")
    public Optional<Question> getQuestionById(@PathVariable Integer id)
    {
        return questionservice.getQuestionById(id);
    }
    @PostMapping
    public void create(@RequestBody Question question)
    {
         questionservice.create(question);
    }

    @GetMapping("/quiz/{quizId}")
    public List<Question> getQuestionsByQuizId(@PathVariable Integer quizId)
    {
        return questionservice.getQuestionsByQuizId(quizId);
    }

}
