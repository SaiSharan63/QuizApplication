package com.quiz.QuestionService.Repository;

import com.quiz.QuestionService.Model.Question;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QuestionRepo extends JpaRepository<Question,Integer> {
    List<Question> findByQuizId(Integer quizId);
}
