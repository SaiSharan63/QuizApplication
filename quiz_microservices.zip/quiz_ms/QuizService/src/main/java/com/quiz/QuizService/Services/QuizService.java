package com.quiz.QuizService.Services;

import com.quiz.QuizService.Model.Quiz;
import com.quiz.QuizService.Repository.QuizRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class QuizService {
    @Autowired
    QuizRepo quizrepo;

    @Autowired
    QuestionClient questionclient;

    public List<Quiz> getQuiz() {
        List<Quiz> quizzes = quizrepo.findAll();
        quizzes.stream().map(quiz ->{
            quiz.setQuestions(questionclient.getQuestionsOfQuiz(quiz.getId()));
            return quiz;
        }).collect(Collectors.toList());
        return quizzes;
    }

    public Quiz getQuizById(Integer id) {
         Quiz quiz =quizrepo.findById(id).orElseThrow(()->new RuntimeException("Quiz not found"));
         quiz.setQuestions(questionclient.getQuestionsOfQuiz(quiz.getId()));
         return quiz;
    }

    public void createQuiz(Quiz quiz) {
        quizrepo.save(quiz);
    }
}
