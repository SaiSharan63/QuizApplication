package com.quiz.QuizService.Controllers;

import com.quiz.QuizService.Model.Quiz;
import com.quiz.QuizService.Services.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("quiz")
public class QuizController {
    @Autowired
    QuizService quizservice;

    @GetMapping("/all")
    public List<Quiz> getQuiz()
    {
        return quizservice.getQuiz();
    }
    @GetMapping("/{id}")
    public Quiz getQuizById(@PathVariable Integer id)
    {
        return quizservice.getQuizById(id);
    }
    @PostMapping("/add")
    public String createQuiz(@RequestBody Quiz quiz)
    {
        quizservice.createQuiz(quiz);
        return "Added succesfully";
    }
}
